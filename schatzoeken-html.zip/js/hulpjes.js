$(document).ready(function(e){$("map").imageMapResize();});
